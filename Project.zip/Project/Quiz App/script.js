document.getElementById('quizForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const answers = {
    q1: "HTML",
    q2: "JavaScript",
    q3: "Hyper Text Markup Language",
    q4: "Styling web pages",
    q5: "a"
    };
    
    let score = 0;
    let total = Object.keys(answers).length;
    
    for (let q in answers) {
        let selected = document.querySelector(`input[name="${q}"]:checked`);
        if (selected && selected.value === answers[q]) {
            score++;
        }
    }
    
    document.getElementById('result').textContent =
    `You scored ${score} out of ${total}`;
});